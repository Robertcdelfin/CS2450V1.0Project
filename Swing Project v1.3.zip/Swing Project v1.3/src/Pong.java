/**
 * file: Pong.java
 * author: Team Goodbye Flash
 * class: CS 2450 - Programming Graphical User Interfaces
 *
 * assignment: Swing Project 
 * date last modified: 10/10/19
 *
 * purpose: This class starts and plays the pong game then pushes things back
 * to the menu.
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import static java.lang.Thread.sleep;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Random;


public class Pong extends JPanel implements ActionListener{

    
    //declares all variables used    
    private JButton quitButton;
    
    private Game game;
    private JLabel scoreLabel;
    
    private JLabel clockLabel;
    private JLabel pongLabel;
    private JLabel player1ScoreLabel;
    private JLabel player2ScoreLabel;
    
    private JLabel player1ScoreValueDisplay;
    private JLabel player2ScoreValueDisplay;
    //The Y cordinate for player 1 for movement
    private int player1YCordinate = 255;
    //the Y cordinate for player 2 for movement
    private int player2YCordinate = 255;
    
    private int player1ScoreValue = 5;
    private int player2ScoreValue = 0;
    
    
    private JButton[] buttons;
    private JLabel[] underscoresLabel;
   
    private Random r = new Random();
    private String choice;
    
    
 
    public Pong(Game game){
        this.game = game;
        //int randomNumber = r.nextInt(words.length);
     
        loadGUI();
        clock();
    }

    public void clock(){ //clock that runs throughout program
        Thread clock = new Thread(){
            public void run(){
                try{
                    for(;;) {
                        Calendar cal = new GregorianCalendar();
                        int day = cal.get(Calendar.DAY_OF_MONTH);
                        int month = cal.get(Calendar.MONTH)+1;
                        int year = cal.get(Calendar.YEAR);

                        int second = cal.get(Calendar.SECOND);
                        int minute = cal.get(Calendar.MINUTE);
                        int hour = cal.get(Calendar.HOUR);

                        clockLabel.setText("Time " + hour + ":" + minute + ":" + second+ " Date " + month + "/" + day + "/" + year);
                        sleep(1000);
                    }
                } catch (InterruptedException e){
                    e.printStackTrace();
                }
            }
        };
        clock.start();
    }

    //Draws the background and displays Pong game
    public void loadGUI(){ 
        
        //labels displaying the players score
        player1ScoreLabel = new JLabel("Player 1");
        player2ScoreLabel = new JLabel("Player 2");
        
        //Label for player score
        
        player1ScoreValueDisplay = new JLabel("Score:" + player1ScoreValue);
        player2ScoreValueDisplay = new JLabel("Score:" + player2ScoreValue);
        
        //pongLabel = new JLabel("Pong");
       
        clockLabel = new JLabel("");
        
        
        //scoreLabel = new JLabel("Score: "+score);
                
        quitButton = new JButton("Quit");
        //quitButton.setBounds(495,300,75,30);
        //quitButton.addActionListener(this);
        
        quitButton.setToolTipText("Returns back to main menu.");

        //Container hold = new Container();

        setLayout(null);
        
        clockLabel.setBounds(400,0,200,20);
        clockLabel.setForeground(Color.BLACK);
        
        player1ScoreLabel.setBounds(0, 50, 200,30);
        player1ScoreLabel.setFont(new Font("Arial", Font.BOLD, 24));
        player1ScoreLabel.setForeground(Color.BLACK);
        
        player1ScoreValueDisplay.setBounds(0, 80, 100, 20);
        player1ScoreValueDisplay.setFont(new Font("Arial", Font.BOLD, 24));
        player1ScoreValueDisplay.setForeground(Color.BLACK);
        
        
        player2ScoreLabel.setBounds(475, 50, 200,30);
        player2ScoreLabel.setFont(new Font("Arial", Font.BOLD, 24));
        player2ScoreLabel.setForeground(Color.BLACK);
        
        player2ScoreValueDisplay.setBounds(475, 75, 100, 30);
        player2ScoreValueDisplay.setFont(new Font("Arial", Font.BOLD, 24));
        player2ScoreValueDisplay.setForeground(Color.BLACK);
        
        //pongLabel.setBounds(10,2,80,32);
        //pongLabel.setFont(new Font("Arial", Font.BOLD, 30));
        //pongLabel.setForeground(Color.red);
        quitButton.setBounds(495,300,75,30);
        quitButton.addActionListener(this);
        add(quitButton);
        //add(pongLabel);
        add(clockLabel);
        add(player1ScoreLabel);
        add(player2ScoreLabel);
        add(player1ScoreValueDisplay);
        add(player2ScoreValueDisplay);
        
        //add(hold);
        add(quitButton);

    }

    public void paintComponent(Graphics g){
        
        super.paintComponent(g);
        Font f = new Font("Arial", Font.BOLD, 32);
    
        Graphics2D background = (Graphics2D)g;
        Graphics2D player1 = (Graphics2D)g;
        Graphics2D player2 = (Graphics2D)g;
        Graphics2D ball = (Graphics2D)g;
      
        background.setFont(f);
        background.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        background.drawString("Pong",0,25);
        //Background for Pong
        background.fillRect(95, 55, 375, 250);
        

        //Player one location
        player1.setColor(Color.WHITE);
        player1.fillRect(110, player1YCordinate, 10, 35);
        //Player two location
        player2.setColor(Color.WHITE);
        player2.fillRect(445, player2YCordinate, 10, 35);
        
        for(int x = 10; x < 10; x++){
            player1YCordinate = player1YCordinate + 10;
            player2YCordinate = player2YCordinate + 20;
            repaint();
        }
        
        int ballXCordinate = 150;
        int ballYCordinate = 150;
        ball.setColor(Color.red);
        ball.fillOval(ballXCordinate, ballYCordinate, 10, 10);
        
        
    }
        


    @Override
    public void actionPerformed(ActionEvent e) {
        Object o = e.getSource();
        JButton b = null;
        String buttonText = "";
        
        Graphics2D background = (Graphics2D)this.getGraphics();
        Graphics2D player1 = (Graphics2D)this.getGraphics();
        Graphics2D player2 = (Graphics2D)this.getGraphics();
        Graphics2D ball = (Graphics2D)this.getGraphics();

        if(o instanceof JButton) {
            b = (JButton) o;
        }
        

        if( b!=null){ //allows access to the button variable and can determine what action to take
            setChoice(b.getText().toLowerCase());
            
              //if player selects quit game ends and menu restarts
            if (choice.equals("quit")){
                game.frame.getContentPane().setVisible(false);
                game.frame.getContentPane().remove(this);
                game.frame.add(new Menu(game));
                game.frame.getContentPane().setVisible(true);
            }
           
           
            
            //boolean end = true; //checks if all spaces have been filled or enough mistakes have been made to end
           
        }
    }
    public void setChoice(String s){
        choice = s;
    }
    public String getChoice(){
        return choice;
    }
}
