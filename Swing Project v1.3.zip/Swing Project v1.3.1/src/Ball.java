
import java.awt.Color;
import java.awt.Graphics;

/**
 * file: Game.java
 * author: Team Goodbye Flash
 * class: CS 2450 - Programming Graphical User Interfaces
 *
 * assignment: Swing Project 
 * date last modified: 9/11/19
 *
 * purpose: This method is for the ball logic.
 *
 ****************************************************************/
public class Ball {
    double xVel, yVel, x, y;
    
    
    public Ball(){
        x = 350;
        y = 250;
        xVel = 0;
        yVel = 1;
    }
    
    public void draw(Graphics g){
        g.setColor(Color.red);
        g.fillOval((int) x, (int)y , 10, 10);
    }
    
    public void move(){
        x += xVel;
        y += yVel;
        
        if(y < 55){
            yVel = -yVel;
        }
        if(y > 295)
            yVel = -yVel;
    }
    
    public int getX(){
        return(int)x;
        
    }
    public int getY(){
        return(int)y;
        
    } 
}
