/**
 * file: Pong.java
 * author: Team Goodbye Flash
 * class: CS 2450 - Programming Graphical User Interfaces
 *
 * assignment: Swing Project 
 * date last modified: 10/20/19
 *
 * purpose: This class starts and plays the pong game then pushes things back
 * to the menu.
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import static java.lang.Thread.sleep;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Random;


public class Pong extends JPanel implements KeyListener, ActionListener{

    //Has something to do with the keybindings or Keylistener
    private Timer t = new Timer(5, this);
   
    //declares all variables used    
    private JButton quitButton;
    
    private Game game;
    private JLabel clockLabel;
    private JLabel player1ScoreLabel;
    private JLabel player1ScoreValueDisplay;
    
    //The Y cordinate for player 1 for movement
    private int player1XCordinate = 110;
    private int player1YCordinate = 255;
    private int player1ScoreValue = 0;
    
    private JLabel player2ScoreLabel;
    private JLabel player2ScoreValueDisplay;
    
    //the Y cordinate for player 2 for movement
    private int player2XCordinate = 445;
    private int player2YCordinate = 255;
    private int player2ScoreValue = 0;
    
    //Cordinates for the ball
    private int ballXCordinate = 120;
    private int ballYCordinate = 280;
    
    private int ballYVelocity = 1;
    private int ballXVelocity = 1;
    
    //Border and point collisions
    //left border of the background for the ball score for player 1
    private int leftBorder = 95;
    //Top Border of the background for the ball
    private int topBorder = 55;
    //rightBorder of the background for the ball score player 2
    private int rightBorder = 460;
    //bottomBorder of the background for the ball to collide
    private int bottomBorder = 295;
    
    private int paddle1YVelocity;
    private int paddle2YVelocity;
    private boolean upAcceleration1;
    private boolean downAcceleration1;
    private boolean upAcceleration2;
    private boolean downAcceleration2;
    private String choice;
    
    
    
    public Pong(Game game){
        this.game = game;
        
        upAcceleration1 = false;
        downAcceleration1 = false;
        upAcceleration2 = false;
        downAcceleration2 = false;
        paddle1YVelocity =0;
        paddle2YVelocity = 0;
        this.addKeyListener(this);
        
        //needed for Key listeners but unsure for keybindings
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
       
        //Saw this was used in keybindings unsure if needed
        t.setInitialDelay(100);
        t.start();
        KeyboardFocusManager.getCurrentKeyboardFocusManager()
                .addKeyEventDispatcher(new KeyEventDispatcher() {
                    @Override
                    public boolean dispatchKeyEvent(KeyEvent e) {
                        if(KeyEvent.KEY_PRESSED == e.getID()){
                            if(e.getKeyCode() == KeyEvent.VK_UP){
                                setUpAcceleration(true);
                            }
                            else if(e.getKeyCode() == KeyEvent.VK_DOWN){
                                setDownAcceleration(true);
                            }
                            if(e.getKeyCode() == KeyEvent.VK_W){
                                setUpAcceleration2(true);
                            }
                            else if(e.getKeyCode() == KeyEvent.VK_S){
                                setDownAcceleration2(true);
                            }
                        }
                        if(KeyEvent.KEY_RELEASED == e.getID()){
                            if(e.getKeyCode() == KeyEvent.VK_UP){
                                setUpAcceleration(false);
                            }
                            else if(e.getKeyCode() == KeyEvent.VK_DOWN){
                                setDownAcceleration(false);
                            }
                            if(e.getKeyCode() == KeyEvent.VK_W){
                                setUpAcceleration2(false);
                            }
                            else if(e.getKeyCode() == KeyEvent.VK_S){
                                setDownAcceleration2(false);
                            }
                        }
                        return false;
                    }
                });
        
        //int randomNumber = r.nextInt(words.length);
        loadGUI();
        clock();
    }

    public void clock(){ //clock that runs throughout program
        Thread clock = new Thread(){
            public void run(){
                try{
                    for(;;) {
                        Calendar cal = new GregorianCalendar();
                        int day = cal.get(Calendar.DAY_OF_MONTH);
                        int month = cal.get(Calendar.MONTH)+1;
                        int year = cal.get(Calendar.YEAR);

                        int second = cal.get(Calendar.SECOND);
                        int minute = cal.get(Calendar.MINUTE);
                        int hour = cal.get(Calendar.HOUR);

                        clockLabel.setText("Time " + hour + ":" + minute + ":" + second+ " Date " + month + "/" + day + "/" + year);
                        sleep(1000);
                    }
                } catch (InterruptedException e){
                    e.printStackTrace();
                }
            }
        };
        clock.start();
    }

    //Draws the background and displays Pong game
    public void loadGUI(){ 
        
        //labels displaying the players score
        player1ScoreLabel = new JLabel("Player 1");
        player2ScoreLabel = new JLabel("Player 2");
        
        //Label for player score
        
        player1ScoreValueDisplay = new JLabel("" + player1ScoreValue);
        player2ScoreValueDisplay = new JLabel("" + player2ScoreValue);
        
       
        clockLabel = new JLabel("");
        
                
        quitButton = new JButton("Quit");
        quitButton.setToolTipText("Returns back to main menu.");
        
        Container hold = new Container();
        setLayout(null);
        
        clockLabel.setBounds(400,0,200,20);
        clockLabel.setForeground(Color.BLACK);
        
        player1ScoreLabel.setBounds(0, 50, 200,30);
        player1ScoreLabel.setFont(new Font("Arial", Font.BOLD, 24));
        player1ScoreLabel.setForeground(Color.BLACK);
        
        player1ScoreValueDisplay.setBounds(0, 80, 100, 20);
        player1ScoreValueDisplay.setFont(new Font("Arial", Font.BOLD, 24));
        player1ScoreValueDisplay.setForeground(Color.BLACK);
        
        
        player2ScoreLabel.setBounds(475, 50, 200,30);
        player2ScoreLabel.setFont(new Font("Arial", Font.BOLD, 24));
        player2ScoreLabel.setForeground(Color.BLACK);
        
        player2ScoreValueDisplay.setBounds(475, 75, 100, 30);
        player2ScoreValueDisplay.setFont(new Font("Arial", Font.BOLD, 24));
        player2ScoreValueDisplay.setForeground(Color.BLACK);
        
        quitButton.setBounds(495,300,75,30);
        quitButton.addActionListener(this);
        
        add(quitButton);
        
        add(clockLabel);
        add(player1ScoreLabel);
        add(player2ScoreLabel);
        add(player1ScoreValueDisplay);
        add(player2ScoreValueDisplay);
        
        add(quitButton);

    }

    public void paintComponent(Graphics g){
        
        super.paintComponent(g);
        
        Font f = new Font("Arial", Font.BOLD, 32);
        //Pong background
        Graphics2D background = (Graphics2D)g;
        background.setFont(f);
        background.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        background.drawString("Pong",0,25);
        //Background for Pong
        //top border = 55, leftBorder = 95, rightBorder = 460 , bottomBorder
        background.fillRect(leftBorder, topBorder, 375, 250);
        
        //player 1 panel
        Graphics2D player1 = (Graphics2D)g;
        //Player one location
        player1.setColor(Color.WHITE);
        
        //player1XCordinate = 110, collides with ball at 120 Xcordinate
        //and to collide ballYCordinatee needs  also to be 
        //between (Player1Ycordinate + 25) 
        player1.fillRect(player1XCordinate, player1YCordinate, 10, 35);
        
        //player 2 panel
        Graphics2D player2 = (Graphics2D)g;
        //Player two location
        
        player2.setColor(Color.WHITE);
        
        //player 2 x cordinate = 445 and for collision
        //x cordinate has to be 435 and YCordinate 
        //needs to be between playerY Cordinate + 25 EX. between (255-280) or (0-25)
        player2.fillRect(player2XCordinate, player2YCordinate, 10, 35);
        
        // draws the ball
        Graphics2D ball = (Graphics2D)g;  
        ball.setColor(Color.red);
        ball.fillOval(ballXCordinate, ballYCordinate, 10, 10);
       
    }
        
    

    @Override
    public void actionPerformed(ActionEvent e) {
        Object o = e.getSource();
        JButton b = null;
        String buttonText = "";
        
        paddleMove();
        paddleMove2();
        move();
        
        
        if(o instanceof JButton) {
            b = (JButton) o;
        }
        if( b!=null){ //allows access to the button variable and can determine what action to take
            setChoice(b.getText().toLowerCase());
            
              //if player selects quit game ends and menu restarts
            if (choice.equals("quit")){
                game.frame.getContentPane().setVisible(false);
                game.frame.getContentPane().remove(this);
                game.frame.add(new Menu(game));
                game.frame.getContentPane().setVisible(true);
            }                   
        }
        
        //If the ball hits the X cordinate of player 1 
        //and the hits the Range of Y cordinate then collides and bounces
        if(ballXCordinate == 120){
            if(ballYCordinate >= player1YCordinate && ballYCordinate <=(player1YCordinate + 25)){
                ballXVelocity = -ballXVelocity;
            }
        }
        else if(ballXCordinate == 435) {
            if(ballYCordinate >= player2YCordinate && ballYCordinate <= (player2YCordinate + 25)){
                ballXVelocity = -ballXVelocity;
            }
        }
        
        //If the ball hits the X cordinate of player 2
        //and his the range of Y cordinate then collides and bounces
        
        
        //the ball hits the right wall point for player 2 and resets board
        if(ballXCordinate == leftBorder){
            player2ScoreValue = player2ScoreValue + 1;
            ballXCordinate = 125;
            player1YCordinate = 255;
            player2YCordinate = 255;
            ballYCordinate = player1YCordinate + 25;
            player2ScoreValueDisplay.setText(""+player2ScoreValue);
        }
        //the ball hits the right wall point for player 1 and resets game
        if(ballXCordinate == rightBorder){
            player1ScoreValue = player1ScoreValue + 1;
            ballXCordinate = 430;
            player1YCordinate = 255;
            player2YCordinate = 255;
            ballYCordinate = player2YCordinate + 25;
            player1ScoreValueDisplay.setText(""+player1ScoreValue);
        }
        repaint();
    }
    public void setChoice(String s){
        choice = s;
    }
    public String getChoice(){
        return choice;
    }

    public void move(){
        ballXCordinate += ballXVelocity;
        ballYCordinate += ballYVelocity;
        if(ballYCordinate < topBorder){
            ballYVelocity = -ballYVelocity;
        }
        if(ballYCordinate > bottomBorder){
            ballYVelocity = -ballYVelocity;
        }
    }
    public void paddleMove(){
        if(upAcceleration1){
            paddle1YVelocity -=1;
        }
        else if(downAcceleration1){
            paddle1YVelocity +=1;
        }
        else if(!upAcceleration1 && !downAcceleration1){
            paddle1YVelocity *= 0.80;
        }    
        if(paddle1YVelocity >= 3){
            paddle1YVelocity = 3;
        }
        else if(paddle1YVelocity <= -3){
            paddle1YVelocity = -3;
        }
        player1YCordinate += paddle1YVelocity;
        
        if(player1YCordinate > bottomBorder -25){
            player1YCordinate = bottomBorder -25;
        }
        if(player1YCordinate < topBorder){
            player1YCordinate = topBorder;
        }
    }
     
       
        
    public void paddleMove2(){
        if(upAcceleration2){
            paddle2YVelocity -=1;
        }
        else if(downAcceleration2){
            paddle2YVelocity +=1;
        }
        else if(!upAcceleration2 && !downAcceleration2){
            paddle2YVelocity *= 0.80;
        }
        if(paddle2YVelocity >= 3){
            paddle2YVelocity = 3;
        }
        else if(paddle2YVelocity <= -3){
            paddle2YVelocity = -3;
        }
        
        player2YCordinate += paddle2YVelocity;
        if(player2YCordinate > bottomBorder -25){
            player2YCordinate = bottomBorder -25;
        }
        if(player2YCordinate < topBorder){
            player2YCordinate = topBorder;
        }
    }
    public void setUpAcceleration(boolean input){
        upAcceleration1 = input;
    }
    public void setUpAcceleration2(boolean input){
        upAcceleration2 = input;
    }
    public void setDownAcceleration(boolean input){
        downAcceleration1 = input;
    }
    public void setDownAcceleration2(boolean input){
        downAcceleration2 = input;
    }
    
    @Override
    public void keyPressed(KeyEvent e) {
    
    }

    @Override
    public void keyReleased(KeyEvent e) {
      
        
    }
    @Override
    public void keyTyped(KeyEvent e) {}
    
}
